public class Question06 {
    byte b;
    boolean B;
    short s;
    int i;
    long l;
    char c;
    float f;
    double d;
    String S;
    public static void main(String[] args) {
        Question06 question06 = new Question06();
        System.out.println("字节型变量 b = " + question06.b);
        System.out.println("短整型变量 s = " + question06.s);
        System.out.println("整型变量 i = " + question06.i);
        System.out.println("长整型变量 l = " + question06.l);
        System.out.println("字符型变量 c = " + question06.c);
        System.out.println("浮点型变量 f = " + question06.f);
        System.out.println("双精度变量 d = " + question06.d);
        System.out.println("布尔型变量 B = " + question06.B);
        System.out.println("字符串对象 S = " + question06.S);
    }
}

public class Question08 {
    public static void main(String args[]) {
        char c = '我';
        System.out.println("\'" + c + "\'的Unicode编码：" + (int) c);
        c = '你';
        System.out.println("\'" + c + "\'的Unicode编码：" + (int) c);
        c = '他';
        System.out.println("\'" + c + "\'的Unicode编码：" + (int) c);

    }
}
public interface IShapeFactory{
    Shape makeShape(double a, double b);
}

package com.oo.aa;
public class A {
	public A(int i) {
		System.out.println("A" + i);
	}
}
class Parent {
  int num = 4;

  protected void foo() {
	System.out.println("foo() of Parent");
  }

  static protected void bar() {
	System.out.println("bar() of Parent");
  }
}
